import tensorflow as tf
from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Dense,Flatten, Dropout

# Load the MNIST dataset
(x_train, y_train), (x_test, y_test) = mnist.load_data()

# Normalize the images
x_train = x_train / 255.0
x_test = x_test / 255.0

# Reshape the images for the CNN
x_train = x_train.reshape(x_train.shape[0], 28, 28, 1)
x_test = x_test.reshape(x_test.shape[0], 28, 28, 1)

# Define the model architecture as a Sequential model
model = Sequential()

# Add the layers to the Sequential model
model.add(Conv2D(32, (3,3), activation='relu', input_shape=(28,28,1)))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(Dropout(0.25))
model.add(Flatten())
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(10, activation='softmax'))

# Compile the model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Train the model
model.fit(x_train, y_train, batch_size=32, epochs=10, validation_data=(x_test, y_test))

# Combine the predictions for two-digit patterns
def predict_two_digits(img1, img2):
    digit1 = model.predict(img1)
    digit2 = model.predict(img2)

    # Combine the predictions to form the final two-digit pattern
    two_digit_pattern = int(str(tf.argmax(digit1, axis=1).numpy()[0]) + str(tf.argmax(digit2, axis=1).numpy()[0]))

    return two_digit_pattern

# Test the model on two-digit patterns
img1 = x_test[0].reshape(1, 28, 28, 1)
img2 = x_test[1].reshape(1, 28, 28, 1)
prediction = predict_two_digits(img1, img2)

print(prediction)

# Save the model
model.save('digit_recognition_model.h5')
