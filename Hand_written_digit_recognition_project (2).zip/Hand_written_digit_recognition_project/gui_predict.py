import tkinter as tk
import tensorflow as tf
from PIL import Image, ImageDraw

# Load the trained model
model = tf.keras.models.load_model('digit_recognition_model.h5')

# Create a canvas to draw on
canvas_width = 400
canvas_height = 200
canvas_color = 'white'

class PaintApp:
    def __init__(self, master):
        self.master = master
        master.title('Digit Recognition')

        # Create a frame for the left canvas
        self.left_frame = tk.Frame(master)
        self.left_frame.pack(side=tk.LEFT)

        # Create a frame for the right canvas
        self.right_frame = tk.Frame(master)
        self.right_frame.pack(side=tk.LEFT)

        # Create the left canvas to draw on
        self.left_canvas = tk.Canvas(self.left_frame, width=canvas_width//2, height=canvas_height, bg=canvas_color)
        self.left_canvas.pack()

        self.left_canvas.bind('<B1-Motion>', self.draw_left)

        # Create the right canvas to draw on
        self.right_canvas = tk.Canvas(self.right_frame, width=canvas_width//2, height=canvas_height, bg=canvas_color)
        self.right_canvas.pack()

        self.right_canvas.bind('<B1-Motion>', self.draw_right)

        self.prediction_label = tk.Label(master, text='')
        self.prediction_label.pack()

        self.clear_button = tk.Button(master, text='Clear', command=self.clear)
        self.clear_button.pack()

        self.predict_button = tk.Button(master, text='Predict', command=self.predict)
        self.predict_button.pack()

        self.image1 = Image.new('L', (canvas_width//2, canvas_height), 0)
        self.draw1 = ImageDraw.Draw(self.image1)

        self.image2 = Image.new('L', (canvas_width//2, canvas_height), 0)
        self.draw2 = ImageDraw.Draw(self.image2)

    def draw_left(self, event):
        x, y = event.x, event.y
        r = 8
        self.left_canvas.create_oval(x-r, y-r, x+r, y+r, fill='black')
        self.draw1.ellipse((x-r, y-r, x+r, y+r), fill=255)

    def draw_right(self, event):
        x, y = event.x, event.y
        r = 8
        self.right_canvas.create_oval(x-r, y-r, x+r, y+r, fill='black')
        self.draw2.ellipse((x-r, y-r, x+r, y+r), fill=255)

    def clear(self):
        self.left_canvas.delete('all')
        self.image1 = Image.new('L', (canvas_width//2, canvas_height), 0)
        self.draw1 = ImageDraw.Draw(self.image1)
        self.right_canvas.delete('all')
        self.image2 = Image.new('L', (canvas_width//2, canvas_height), 0)
        self.draw2 = ImageDraw.Draw(self.image2)
        self.prediction_label.configure(text='')

    def predict(self):
        digit_names = {
            0: 'zero', 
            1: 'one', 
            2: 'two', 
            3: 'three', 
            4: 'four', 
            5: 'five', 
            6: 'six', 
            7: 'seven', 
            8: 'eight', 
            9: 'nine'
                    }
        if self.image1.getbbox() is None:
            digit1 = 0
            name1 = ''
        else:
            x1 = tf.keras.preprocessing.image.img_to_array(self.image1.resize((28, 28)))
            x1 = x1.reshape(1, 28, 28, 1) / 255.0
            digit1 = model.predict(x1)[0].argmax()
            name1 = digit_names[digit1]

        if self.image2.getbbox() is None:
            digit2 = digit1
            digit1=0
            name2 = ''
        else:
            x2 = tf.keras.preprocessing.image.img_to_array(self.image2.resize((28, 28)))
            x2 = x2.reshape(1, 28, 28, 1) / 255.0
            digit2 = model.predict(x2)[0].argmax()
            name2 = digit_names[digit2]

        if name1 and name2:
            prediction_text = f'Prediction: {name1} {name2}'
            prediction_digit = f'Prediction: {digit1} {digit2}'
        else:
            prediction_text = f'Prediction: {name1}{name2}'
            prediction_digit = f'Prediction: {digit1}{digit2}'
        self.prediction_label.configure(text=f'{prediction_text}\n{prediction_digit}')
       


root = tk.Tk()
app = PaintApp(root)
root.mainloop()
